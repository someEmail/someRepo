#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 26 11:10:01 2017

@author: sarnayak
"""

import random

def dist(a, b):
    return (a-b) * (a-b)

def getnearest(d, km):
    return min(range(len(km)), key=lambda x: dist(km[x], d))

def k_means(data, k):
    if len(set(data)) < k:
        raise Exception('The data size is less than k')
    
    # 1. k initial "means" are randomly selected from the data set.
    kms = set()
    while len(kms) < k:
        kms.add(random.choice(data))
    
    km = sorted(kms) # [data[i] for i in kmi]
    #print(km)

    pl = []

    while True:
        # 2. k clusters are created by associating every observation with the nearest mean.
        clus = {i: 0 for i in range(k)}
        clul = {i: 0 for i in range(k)}
        cl = []
        for di in data:
            c = getnearest(di, km)
            clus[c] += di
            clul[c] += 1
            cl.append(c)
   
        #print(clul)
        # 3. The centroid of each of the k clusters becomes the new means.
        nkm = []
        for c in range(k):
            nkm.append(clus[c] / clul[c])
        km = nkm
        
        # 4. ...repeat until convergence has been reached.
        if pl == cl:
            break
        pl = cl
        #print(km)
    
    clu = {i: [] for i in range(k)}
    for di in data:
        c = getnearest(di, km)
        clu[c].append(di)
    
    return zip(km, clu.values())

if __name__ == '__main__':
    Ages = [15,15,16,19,19,20,20,21,22,28,35,40,41,42,43,44,60,61,65]
    print(list(k_means(Ages, 10)))

